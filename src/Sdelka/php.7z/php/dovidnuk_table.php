<?php
    session_start();
    $pdo = null;
    require_once("pdoconnect.php");
    
    $roles = $_POST['dovid'];
    $result = array();
    $sql = "select dt.name_col, dt.name_table, dt.name_table_row, dt.ref_table, dt.ref_key, dt.ref_row, dt.setorder
            from Dovidnuku d, Dov_table dt
            where d.code_dovid = ".$roles." and d.id = dt.id_dov
            order by dt.ord
            ";
    $res = $pdo->query($sql);
    $r = $res->fetchAll();
    
    for ($i = 0; $i < count($r); $i++){
        $result[$i]['name_col'] = $r[$i]['name_col']; 
        $result[$i]['name_table'] = $r[$i]['name_table_row']; 
    echo json_encode($result);
?>