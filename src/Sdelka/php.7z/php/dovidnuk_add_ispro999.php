<?php
/**
 * Created by PhpStorm.
 * User: shushkevych-iv
 * Date: 12.02.2019
 * Time: 12:32
 */


class Test extends PHPUnit_Framework_TestCase
{

}
