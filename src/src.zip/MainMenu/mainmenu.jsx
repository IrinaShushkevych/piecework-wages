import React from 'react';
import {NavLink} from 'react-router-dom';

let MainMenus = (props) => {
    let MainMenu = props.store.state.SelectAccess.map((a) => { 
        let str = "/main";
        return ( 
            <NavLink className='dovbutton' to={{pathname:str, state:a.code_dov}} >
                <span>    
                    {a.name_dovid}
                </span>
            </NavLink> 
            )
    });

    return(
            <div className='wraper'>
                <div className='navdiv'>
                    <div className='ribbon'>
                        {MainMenu}
                    </div>
                </div>
            </div>
    )
}

export default MainMenus;