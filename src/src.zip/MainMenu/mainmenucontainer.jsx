import React from 'react';
import MainMenus from './mainmenu';

let f1 = () => {}

let f1 = () => {}

let MainMenuContainer = connect()(MainMenus);


export default MainMenuContainer;