import React from 'react';
import LoginContainer from './Login/logincontainer.jsx';
import MainBody from './MainBody/mainbody.jsx';

let App = (props) => {
    console.log( props.paths);
    debugger;
    return <div>
            <LoginContainer />}
             <MainBody />}
        </div>
}

export default App;