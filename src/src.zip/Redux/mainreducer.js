const LOGIN = 'login';
const LOGOUT = 'logout';

let initialState = {
    userRoles : 0,
    SelectAccess : [
          {name_dovid :'Адміністрування', code_dov:"1"}, 
          {name_dovid :'Табелювання', code_dov:"2"},
          {name_dovid :'Довідник', code_dov:"3"},
          {name_dovid :'Вихід', code_dov:"4"},
    ],

    SelectMenu : [
        {name_dovid :'Норми виробітку', code_dov:"1"}, 
        {name_dovid :'Робочі місця', code_dov:"2"},
        {name_dovid :'Працівники', code_dov:"3"},
        {name_dovid :'Підрозділи', code_dov:"4"},
        {name_dovid :'Посади', code_dov:"5"}, 
        {name_dovid :'Бригади', code_dov:"6"},
        {name_dovid :'Режим роботии', code_dov:"7"},
        {name_dovid :'Одиниці виміру', code_dov:"8"},
        {name_dovid :'Вид пошти', code_dov:"9"},
        {name_dovid :'Користувачі', code_dov:"10"},
    ]
}

export const setLoginAction = (log, pas) => ({type : LOGIN, logname : log, password: pas})
export const setLogoutAction = () => ({type : LOGOUT})

let logUserReducer = (state = initialState, action)  => {
    switch(action.type){
        case LOGIN :
            state.userLogin = action.logname;
            state.userPassword = action.password; 
            state.paths = '/main';
            return state;
        case LOGOUT :
                state.userLogin = '';
                state.userPassword = ''; 
                state.paths = '/';
                return state;
        default : return state;
    }
}

export default logUserReducer;