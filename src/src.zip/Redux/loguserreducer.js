const LOGIN = 'login';
const LOGOUT = 'logout';
const LOGNAME = 'logname';
const PASSWORD = 'password';

let initialState = {
        userLogin : '',
        userPassword : '',
        userName : '',
        userId : 0,
        userAccess : 0,
         userRoles :null
    }

export const setConnectAction = (log, pas) => ({type : LOGIN, logname : log, password: pas})
export const setDisconnectAction = () => ({type : LOGOUT})
export const setLogAction = (log) => ({type : LOGNAME, logname : log})
export const setPassAction = (pass) => ({type : PASSWORD, password: pass})

let logUserReducer = (state = initialState, action) => {
    switch(action.type){
        case LOGIN : 
            return  {
                ...state, 
                userLogin : action.logname,
                userPassword : action.password,
                userId : 1
            }
        case LOGOUT : 
            return {
                ...state, 
                userLogin : '',
                userPassword : '',
                userId : 0
            }
        case LOGNAME : 
            return {
                ...state, 
                userLogin : action.logname
            }
        case PASSWORD : 
            return {
                ...state,
                userPassword : action.password
            }
        default : return state;
    }
}

export default logUserReducer;