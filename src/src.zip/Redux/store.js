let store = {
    state : {
        userLogin : '1',
        userPassword : '1',
        userRoles : 0,
        userName : '',
        paths : '/',
        userAccess : 0,
        SelectAccess : [
                   {name_dovid :'Адміністрування', code_dov:"1"}, 
                  {name_dovid :'Табелювання', code_dov:"2"},
                  {name_dovid :'Довідник', code_dov:"3"},
                  {name_dovid :'Вихід', code_dov:"4"},
        ],

         SelectMenu : [
            {name_dovid :'Норми виробітку', code_dov:"1"}, 
            {name_dovid :'Робочі місця', code_dov:"2"},
            {name_dovid :'Працівники', code_dov:"3"},
            {name_dovid :'Підрозділи', code_dov:"4"},
            {name_dovid :'Посади', code_dov:"5"}, 
            {name_dovid :'Бригади', code_dov:"6"},
            {name_dovid :'Режим роботии', code_dov:"7"},
            {name_dovid :'Одиниці виміру', code_dov:"8"},
            {name_dovid :'Вид пошти', code_dov:"9"},
            {name_dovid :'Користувачі', code_dov:"10"},
        ],

        DataSelectionConditions : [
           
        ]
    },

    _subscriber(){
        console.log("no subscriber");
    },

    subscriber(observer){
        this._subscriber = observer;
    },

    setLogin(log){
        this.userLogin = log;
        this._subscriber();
    },

    setPassword(pass){
        this.userPassword = pass;
        this._subscriber();
    },

    login (login, pass) {
        if (login==='1' && pass==='1'){
            this.userLogin = login;
            this.userPassword = pass;
            this.paths = '/main';
            alert("Login");
        }
    },

    setUserRoles(role){
        this.userRoles = role;
    }

}

export default store;