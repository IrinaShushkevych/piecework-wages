const LOGIN = 'login';
const LOGOUT = 'logout';

let initialState = {
    DataSelectionConditions : []
}

export const setLoginAction = (log, pas) => ({type : LOGIN, logname : log, password: pas})
export const setLogoutAction = () => ({type : LOGOUT})

let logUserReducer = (state = initialState, action) => {
    switch(action.type){
        case LOGIN :
            state.userLogin = action.logname;
            state.userPassword = action.password; 
            state.paths = '/main';
            return state;
        case LOGOUT :
                state.userLogin = '';
                state.userPassword = ''; 
                state.paths = '/';
                return state;
        default : return state;
    }
}

export default logUserReducer;