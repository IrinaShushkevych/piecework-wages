import {createStore, combineReducers} from 'redux';
import logUserReducer from './loguserreducer';
import dovidnukReducer from './dovidnukreducer';
import mainReducer from './mainreducer';

let reducers = combineReducers({loguser:logUserReducer, main:mainReducer, dovidnuk:dovidnukReducer});
let store = createStore(reducers);

export default store;