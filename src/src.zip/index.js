import ReactDOM from 'react-dom';
import './index.css';
import AppMain from './appmain';

ReactDOM.render( AppMain, document.getElementById('root')
    );
