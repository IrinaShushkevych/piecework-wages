import * as axios from 'axios';

export const getUsers = () => {
	return axios.get('', { withCredentials: true}).then(response => response.data);
}