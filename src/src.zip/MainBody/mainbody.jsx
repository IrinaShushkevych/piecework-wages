import React from 'react';
import {Route} from 'react-router-dom';
import MainMenus from './../MainMenu/mainmenu';
import SecondMenu from './../SecondMenu/secondmenu';

let MainBody = (props) => {
    
    return (
        <div>
            <hr />
           <MainMenus store={props.store} /> 
           <hr />
            <Route path='/main/:idfm' render={() => <SecondMenu store={props.store}/>}/>   
            
        </div>
    )
}

export default MainBody;