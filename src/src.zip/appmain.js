import React from 'react';
import {BrowserRouter} from 'react-router-dom';
import {Provider} from 'react-redux';
import './index.css';
import App from './App';
import store from './Redux/reduxstore';

let AppMain = () => {
console.log('AppMain');
debugger;
    return <BrowserRouter>
            <Provider store={store}>
                <App paths={store.getState().loguser.paths}/>
            </ Provider>
        </ BrowserRouter>
};

export default AppMain