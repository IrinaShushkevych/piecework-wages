import React from 'react';

let Tables = (props) => {
    
    console.log("Hello222");

    let T = () => {
        console.log('22');
        if ( props.store.state.DataSelectionConditions.length === 0 ){
            return (<label>Tables</label>);
        } else {
            return '';
        }
    }

    return(
        <div>
           {T()}
        </div>
    )
}

export default Tables;