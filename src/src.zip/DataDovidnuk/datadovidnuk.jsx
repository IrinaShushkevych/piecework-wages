import React from 'react';
import SelectionConditions from './../DataDovidnuk/selectionconditions';
import Tables from './../DataDovidnuk/tables';

let DataDovidnuk = (props) => {
    
    console.log("Hello1111");

    let Dovidnuku = () => {
        if ( props.store.state.DataSelectionConditions.length > 0 ){
            return <SelectionConditions store={props.store}/>;
        } else {
            console.log(props.store.state.DataSelectionConditions.length);
            return <Tables store={props.store}/>;
        }
    }

    return(
        <div>
           {Dovidnuku()}
        </div>
    )
}

export default DataDovidnuk;