import React from 'react';
import {NavLink, Route} from 'react-router-dom';
import DataDovidnuk from './../DataDovidnuk/datadovidnuk';

let SecondMenu = (props) => {
    
    let SecMenu = props.store.state.SelectMenu.map((a) => {
                                        let str = '/main/3/$'+a.code_dov;
                                        return (
                                                <NavLink className='dovbutton' to={str}>
                                                    <span>
                                                        {a.name_dovid}
                                                    </span>
                                                </NavLink>
                                        )})

    return(
        <div>
            <div className='wraper'>
                <div className='navdiv'>
                    <div className='ribbon'>
                        {SecMenu}
                    </div>
                </div>
            </div>
            <hr />
            <Route path='/main/3/:idd' render={() => <DataDovidnuk store={props.store}/>}/>   
        </div>
    )
}

export default SecondMenu;