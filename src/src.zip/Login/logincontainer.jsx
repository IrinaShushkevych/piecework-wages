import React from 'react';
import Login from './login';
import {setConnectAction, setDisconnectAction, setLogAction, setPassAction} from './../Redux/loguserreducer';
import {connect} from 'react-redux';


class LoginContainer extends React.Component {
    
    render() {
        debugger;
        return <Login {...this.props}/>
        
    }
}

let mapStateToProps = (state) => {
    return {
        userData : state.loguser
    }
}

let mapDispatchToProps = (dispatch) => {
    return {
       ConnectingUser : (log, pas) => {
          dispatch(setConnectAction(log, pas));
       },
       DisconectingUser : () => {
          dispatch(setDisconnectAction());
       },
       SetLogin : (log) =>{
           dispatch(setLogAction(log));
       },
       SetPassword : (pass) =>{
            dispatch(setPassAction(pass));
       }
    }
}



export default connect(mapStateToProps, mapDispatchToProps)(LoginContainer);;
