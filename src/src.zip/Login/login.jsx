import React from 'react';


let NewLogin = React.createRef();
let NewPass = React.createRef();
 
let Login = (props) => {
    if (props.userData.userId !== 0) {
    return (
        <div className='sdelkamain'>
            <input type="text" 
                        placeholder="Enter your login" 
                        ref={NewLogin}
                        value={props.userData.userLogin} 
                        onChange={()=>{props.SetLogin(NewLogin.current.value)}}
                        ></input>
            <input type="text" 
                        placeholder="Enter your password" 
                        ref={NewPass}
                        value={props.userData.userPassword}
                        onChange={()=>{props.SetPassword(NewPass.current.value)}}
                        ></input>
                <button onClick={ () => {
                            let newl = NewLogin.current.value;
                            let newp = NewPass.current.value;
                            props.ConnectingUser(newl,newp);
                            console.log('login1');
                            }}>
                        Вхід
                </button>
        </div>
    )}
    else return null
}

export default Login;